<?php
/**
 * @category   Ktpl
 * @package    Ktpl_RequestForQuote
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Ktpl_RequestForQuote',
    __DIR__
);
